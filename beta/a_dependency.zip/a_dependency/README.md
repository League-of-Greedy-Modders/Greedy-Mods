# Greed Dependency Test

This mod is just for dependency testing.
